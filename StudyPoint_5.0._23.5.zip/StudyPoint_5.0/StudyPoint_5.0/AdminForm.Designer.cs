﻿namespace StudyPoint_5._0
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NaviPL = new System.Windows.Forms.Panel();
            this.PoistuBT = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.KayttajaBT = new System.Windows.Forms.Button();
            this.KyselytBT = new System.Windows.Forms.Button();
            this.LatauksetBT = new System.Windows.Forms.Button();
            this.kayttajahallinta1 = new StudyPoint_5._0.KAYTTAJAHALLINTA();
            this.etusivu1 = new StudyPoint_5._0.ETUSIVU();
            this.NaviPL.SuspendLayout();
            this.SuspendLayout();
            // 
            // NaviPL
            // 
            this.NaviPL.BackColor = System.Drawing.Color.RoyalBlue;
            this.NaviPL.Controls.Add(this.PoistuBT);
            this.NaviPL.Controls.Add(this.button1);
            this.NaviPL.Controls.Add(this.KayttajaBT);
            this.NaviPL.Controls.Add(this.KyselytBT);
            this.NaviPL.Controls.Add(this.LatauksetBT);
            this.NaviPL.Dock = System.Windows.Forms.DockStyle.Top;
            this.NaviPL.Location = new System.Drawing.Point(0, 0);
            this.NaviPL.Margin = new System.Windows.Forms.Padding(5);
            this.NaviPL.Name = "NaviPL";
            this.NaviPL.Size = new System.Drawing.Size(1396, 71);
            this.NaviPL.TabIndex = 3;
            // 
            // PoistuBT
            // 
            this.PoistuBT.BackColor = System.Drawing.Color.Red;
            this.PoistuBT.FlatAppearance.BorderSize = 0;
            this.PoistuBT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PoistuBT.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PoistuBT.Location = new System.Drawing.Point(1327, 5);
            this.PoistuBT.Margin = new System.Windows.Forms.Padding(5);
            this.PoistuBT.Name = "PoistuBT";
            this.PoistuBT.Size = new System.Drawing.Size(64, 60);
            this.PoistuBT.TabIndex = 7;
            this.PoistuBT.Text = "Ulos";
            this.PoistuBT.UseVisualStyleBackColor = false;
            this.PoistuBT.Click += new System.EventHandler(this.PoistuBT_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.RoyalBlue;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(5, 6);
            this.button1.Margin = new System.Windows.Forms.Padding(5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 60);
            this.button1.TabIndex = 5;
            this.button1.Text = "Etusivu";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // KayttajaBT
            // 
            this.KayttajaBT.BackColor = System.Drawing.Color.RoyalBlue;
            this.KayttajaBT.FlatAppearance.BorderSize = 0;
            this.KayttajaBT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.KayttajaBT.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KayttajaBT.ForeColor = System.Drawing.SystemColors.Control;
            this.KayttajaBT.Location = new System.Drawing.Point(470, 5);
            this.KayttajaBT.Margin = new System.Windows.Forms.Padding(5);
            this.KayttajaBT.Name = "KayttajaBT";
            this.KayttajaBT.Size = new System.Drawing.Size(145, 60);
            this.KayttajaBT.TabIndex = 2;
            this.KayttajaBT.Text = "Käyttäjä hallinta";
            this.KayttajaBT.UseVisualStyleBackColor = false;
            this.KayttajaBT.Click += new System.EventHandler(this.KayttajaBT_Click);
            // 
            // KyselytBT
            // 
            this.KyselytBT.BackColor = System.Drawing.Color.RoyalBlue;
            this.KyselytBT.FlatAppearance.BorderSize = 0;
            this.KyselytBT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.KyselytBT.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KyselytBT.ForeColor = System.Drawing.SystemColors.Control;
            this.KyselytBT.Location = new System.Drawing.Point(315, 6);
            this.KyselytBT.Margin = new System.Windows.Forms.Padding(5);
            this.KyselytBT.Name = "KyselytBT";
            this.KyselytBT.Size = new System.Drawing.Size(145, 60);
            this.KyselytBT.TabIndex = 1;
            this.KyselytBT.Text = "Kyselyjen hallinta";
            this.KyselytBT.UseVisualStyleBackColor = false;
            // 
            // LatauksetBT
            // 
            this.LatauksetBT.BackColor = System.Drawing.Color.RoyalBlue;
            this.LatauksetBT.FlatAppearance.BorderSize = 0;
            this.LatauksetBT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LatauksetBT.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LatauksetBT.ForeColor = System.Drawing.SystemColors.Control;
            this.LatauksetBT.Location = new System.Drawing.Point(160, 5);
            this.LatauksetBT.Margin = new System.Windows.Forms.Padding(5);
            this.LatauksetBT.Name = "LatauksetBT";
            this.LatauksetBT.Size = new System.Drawing.Size(145, 60);
            this.LatauksetBT.TabIndex = 0;
            this.LatauksetBT.Text = "Latausten hallinta";
            this.LatauksetBT.UseVisualStyleBackColor = false;
            // 
            // kayttajahallinta1
            // 
            this.kayttajahallinta1.BackColor = System.Drawing.SystemColors.Control;
            this.kayttajahallinta1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kayttajahallinta1.Location = new System.Drawing.Point(0, 71);
            this.kayttajahallinta1.Name = "kayttajahallinta1";
            this.kayttajahallinta1.Size = new System.Drawing.Size(1396, 756);
            this.kayttajahallinta1.TabIndex = 5;
            // 
            // etusivu1
            // 
            this.etusivu1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.etusivu1.Location = new System.Drawing.Point(0, 71);
            this.etusivu1.Name = "etusivu1";
            this.etusivu1.Size = new System.Drawing.Size(1396, 756);
            this.etusivu1.TabIndex = 4;
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1396, 827);
            this.Controls.Add(this.kayttajahallinta1);
            this.Controls.Add(this.etusivu1);
            this.Controls.Add(this.NaviPL);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            this.Load += new System.EventHandler(this.AdminForm_Load);
            this.NaviPL.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel NaviPL;
        private System.Windows.Forms.Button PoistuBT;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button KayttajaBT;
        private System.Windows.Forms.Button KyselytBT;
        private System.Windows.Forms.Button LatauksetBT;
        private ETUSIVU etusivu1;
        private KAYTTAJAHALLINTA kayttajahallinta1;
    }
}