﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace StudyPoint_5._0
{
    public partial class KAYTTAJA : UserControl
    {
         
       

        public KAYTTAJA()
        {
            InitializeComponent();
        }

        private void KirjauduUlosBT_Click(object sender, EventArgs e)
        {
            DialogResult Exit;

            try
            {
                Exit = MessageBox.Show("Haluatko varmasti kirjautua ulos?", "Uloskirjautuminen", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (Exit == DialogResult.Yes)
                {
                    Application.Exit();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void KAYTTAJA_Load(object sender, EventArgs e)
        {
            /*String enimi = "";
            String snimi = "";
            String puh = "";
            String email = "";
            String lahos = "";
            String ptp = "";
            String pnro = "";
            String usr = "";

            MySqlCommand cmd = new MySqlCommand("SELECT `etunimi`,`sukunimi`,`puhelin`,`sahkoposti`,`lahiosoite`,`postitoimipaikka`,`postinro`,`kayttaja` FROM `opiskelija` WHERE `etunimi`= @enm ,`sukunimi` =@snm ,`puhelin`= @puh,`sahkoposti` =@eml,`lahiosoite`= @lahos,`postitoimipaikka` = @ptp,`postinro` = @pnro,`kayttaja` = @usr ", yhteys.otaYhteys());
            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.SelectCommand = cmd;
            adapter.Fill(dt);

            cmd.Parameters.Add("@enm", MySqlDbType.VarChar).Value = enimi;
            cmd.Parameters.Add("@snm", MySqlDbType.VarChar).Value = snimi;
            cmd.Parameters.Add("@puh", MySqlDbType.VarChar).Value = puh;
            cmd.Parameters.Add("@eml", MySqlDbType.VarChar).Value = email;
            cmd.Parameters.Add("@lahos", MySqlDbType.VarChar).Value = lahos;
            cmd.Parameters.Add("@ptp", MySqlDbType.VarChar).Value = ptp;
            cmd.Parameters.Add("@pnro", MySqlDbType.VarChar).Value = pnro;
            cmd.Parameters.Add("@usr", MySqlDbType.VarChar).Value = usr;

            enimiLB.Text = enimi;

            snimiLB.Text=snimi;
            puhLB.Text=puh;
            SpostiLB.Text=email;
            LahOsLB.Text=lahos;
            PtpLB.Text=ptp;
            PnroLB.Text=pnro;
            KayttajaNimiLB.Text=usr;*/


           
        }
    }
}
