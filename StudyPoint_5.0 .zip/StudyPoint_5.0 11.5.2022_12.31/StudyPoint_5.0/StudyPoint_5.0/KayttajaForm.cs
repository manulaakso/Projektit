﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyPoint_5._0
{
    public partial class KayttajaForm : Form
    {
        public KayttajaForm()
        {
            InitializeComponent();
        }

        private void etusivu1_Load(object sender, EventArgs e)
        {

        }
    }
}
