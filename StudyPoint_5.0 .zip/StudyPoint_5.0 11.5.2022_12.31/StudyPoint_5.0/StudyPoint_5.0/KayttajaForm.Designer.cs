﻿namespace StudyPoint_5._0
{
    partial class KayttajaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelPL = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.AdminGB = new System.Windows.Forms.ComboBox();
            this.NaviPL = new System.Windows.Forms.Panel();
            this.PalveluBT = new System.Windows.Forms.Button();
            this.UserGB = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.OrganiBT = new System.Windows.Forms.Button();
            this.GalleriaBT = new System.Windows.Forms.Button();
            this.OtayhteyttaBT = new System.Windows.Forms.Button();
            this.salasana1 = new StudyPoint_5._0.SALASANA();
            this.organisaatiomme1 = new StudyPoint_5._0.ORGANISAATIOMME();
            this.kayttaja1 = new StudyPoint_5._0.KAYTTAJA();
            this.palvelumme1 = new StudyPoint_5._0.PALVELUMME();
            this.PanelPL.SuspendLayout();
            this.NaviPL.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelPL
            // 
            this.PanelPL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PanelPL.Controls.Add(this.comboBox1);
            this.PanelPL.Controls.Add(this.salasana1);
            this.PanelPL.Controls.Add(this.organisaatiomme1);
            this.PanelPL.Controls.Add(this.kayttaja1);
            this.PanelPL.Controls.Add(this.palvelumme1);
            this.PanelPL.Controls.Add(this.AdminGB);
            this.PanelPL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelPL.Location = new System.Drawing.Point(0, 71);
            this.PanelPL.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.PanelPL.Name = "PanelPL";
            this.PanelPL.Size = new System.Drawing.Size(1396, 756);
            this.PanelPL.TabIndex = 5;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Palautteen hallinta",
            "Kyselyjenhallinta",
            "Käyttäjien hallinta",
            "Mitä uutta hallinta",
            "Latausten hallinta"});
            this.comboBox1.Location = new System.Drawing.Point(1139, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(245, 31);
            this.comboBox1.TabIndex = 15;
            this.comboBox1.Visible = false;
            // 
            // AdminGB
            // 
            this.AdminGB.FormattingEnabled = true;
            this.AdminGB.Items.AddRange(new object[] {
            "Palautteen hallinta",
            "Kyselyjenhallinta",
            "Käyttäjien hallinta",
            "Mitä uutta hallinta",
            "Latausten hallinta"});
            this.AdminGB.Location = new System.Drawing.Point(977, 26);
            this.AdminGB.Name = "AdminGB";
            this.AdminGB.Size = new System.Drawing.Size(245, 21);
            this.AdminGB.TabIndex = 7;
            this.AdminGB.Visible = false;
            // 
            // NaviPL
            // 
            this.NaviPL.BackColor = System.Drawing.Color.RoyalBlue;
            this.NaviPL.Controls.Add(this.PalveluBT);
            this.NaviPL.Controls.Add(this.UserGB);
            this.NaviPL.Controls.Add(this.button1);
            this.NaviPL.Controls.Add(this.OrganiBT);
            this.NaviPL.Controls.Add(this.GalleriaBT);
            this.NaviPL.Controls.Add(this.OtayhteyttaBT);
            this.NaviPL.Dock = System.Windows.Forms.DockStyle.Top;
            this.NaviPL.Location = new System.Drawing.Point(0, 0);
            this.NaviPL.Margin = new System.Windows.Forms.Padding(5);
            this.NaviPL.Name = "NaviPL";
            this.NaviPL.Size = new System.Drawing.Size(1396, 71);
            this.NaviPL.TabIndex = 4;
            // 
            // PalveluBT
            // 
            this.PalveluBT.BackColor = System.Drawing.Color.RoyalBlue;
            this.PalveluBT.FlatAppearance.BorderSize = 0;
            this.PalveluBT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PalveluBT.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PalveluBT.Location = new System.Drawing.Point(637, 5);
            this.PalveluBT.Margin = new System.Windows.Forms.Padding(5);
            this.PalveluBT.Name = "PalveluBT";
            this.PalveluBT.Size = new System.Drawing.Size(145, 60);
            this.PalveluBT.TabIndex = 7;
            this.PalveluBT.Text = "Palvelumme";
            this.PalveluBT.UseVisualStyleBackColor = false;
            // 
            // UserGB
            // 
            this.UserGB.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserGB.FormattingEnabled = true;
            this.UserGB.Items.AddRange(new object[] {
            "Ohjeita",
            "Palaute",
            "Vaihda salasana",
            "Käyttäjä Profiili",
            "Lataukset",
            "Mitä uutta?"});
            this.UserGB.Location = new System.Drawing.Point(1139, 21);
            this.UserGB.Name = "UserGB";
            this.UserGB.Size = new System.Drawing.Size(245, 31);
            this.UserGB.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.RoyalBlue;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(5, 6);
            this.button1.Margin = new System.Windows.Forms.Padding(5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 60);
            this.button1.TabIndex = 5;
            this.button1.Text = "Etusivu";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // OrganiBT
            // 
            this.OrganiBT.BackColor = System.Drawing.Color.RoyalBlue;
            this.OrganiBT.FlatAppearance.BorderSize = 0;
            this.OrganiBT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrganiBT.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrganiBT.Location = new System.Drawing.Point(470, 5);
            this.OrganiBT.Margin = new System.Windows.Forms.Padding(5);
            this.OrganiBT.Name = "OrganiBT";
            this.OrganiBT.Size = new System.Drawing.Size(157, 60);
            this.OrganiBT.TabIndex = 4;
            this.OrganiBT.Text = "Organisaatiomme";
            this.OrganiBT.UseVisualStyleBackColor = false;
            // 
            // GalleriaBT
            // 
            this.GalleriaBT.BackColor = System.Drawing.Color.RoyalBlue;
            this.GalleriaBT.FlatAppearance.BorderSize = 0;
            this.GalleriaBT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GalleriaBT.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GalleriaBT.Location = new System.Drawing.Point(315, 6);
            this.GalleriaBT.Margin = new System.Windows.Forms.Padding(5);
            this.GalleriaBT.Name = "GalleriaBT";
            this.GalleriaBT.Size = new System.Drawing.Size(145, 60);
            this.GalleriaBT.TabIndex = 3;
            this.GalleriaBT.Text = "Galleria";
            this.GalleriaBT.UseVisualStyleBackColor = false;
            // 
            // OtayhteyttaBT
            // 
            this.OtayhteyttaBT.BackColor = System.Drawing.Color.RoyalBlue;
            this.OtayhteyttaBT.FlatAppearance.BorderSize = 0;
            this.OtayhteyttaBT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OtayhteyttaBT.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OtayhteyttaBT.Location = new System.Drawing.Point(160, 5);
            this.OtayhteyttaBT.Margin = new System.Windows.Forms.Padding(5);
            this.OtayhteyttaBT.Name = "OtayhteyttaBT";
            this.OtayhteyttaBT.Size = new System.Drawing.Size(145, 60);
            this.OtayhteyttaBT.TabIndex = 2;
            this.OtayhteyttaBT.Text = "Ota yhteyttä";
            this.OtayhteyttaBT.UseVisualStyleBackColor = false;
            // 
            // salasana1
            // 
            this.salasana1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.salasana1.Location = new System.Drawing.Point(0, 0);
            this.salasana1.Name = "salasana1";
            this.salasana1.Size = new System.Drawing.Size(1396, 756);
            this.salasana1.TabIndex = 14;
            // 
            // organisaatiomme1
            // 
            this.organisaatiomme1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.organisaatiomme1.Location = new System.Drawing.Point(0, 0);
            this.organisaatiomme1.Name = "organisaatiomme1";
            this.organisaatiomme1.Size = new System.Drawing.Size(1396, 756);
            this.organisaatiomme1.TabIndex = 13;
            // 
            // kayttaja1
            // 
            this.kayttaja1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kayttaja1.Location = new System.Drawing.Point(0, 0);
            this.kayttaja1.Name = "kayttaja1";
            this.kayttaja1.Size = new System.Drawing.Size(1396, 756);
            this.kayttaja1.TabIndex = 12;
            // 
            // palvelumme1
            // 
            this.palvelumme1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.palvelumme1.Location = new System.Drawing.Point(0, 0);
            this.palvelumme1.Name = "palvelumme1";
            this.palvelumme1.Size = new System.Drawing.Size(1396, 756);
            this.palvelumme1.TabIndex = 11;
            // 
            // KayttajaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1396, 827);
            this.Controls.Add(this.PanelPL);
            this.Controls.Add(this.NaviPL);
            this.Name = "KayttajaForm";
            this.Text = "KayttajaForm";
            this.PanelPL.ResumeLayout(false);
            this.NaviPL.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelPL;
        private System.Windows.Forms.ComboBox comboBox1;
        private SALASANA salasana1;
        private ORGANISAATIOMME organisaatiomme1;
        private KAYTTAJA kayttaja1;
        private PALVELUMME palvelumme1;
        private System.Windows.Forms.ComboBox AdminGB;
        private System.Windows.Forms.Panel NaviPL;
        private System.Windows.Forms.Button PalveluBT;
        private System.Windows.Forms.ComboBox UserGB;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button OrganiBT;
        private System.Windows.Forms.Button GalleriaBT;
        private System.Windows.Forms.Button OtayhteyttaBT;
    }
}