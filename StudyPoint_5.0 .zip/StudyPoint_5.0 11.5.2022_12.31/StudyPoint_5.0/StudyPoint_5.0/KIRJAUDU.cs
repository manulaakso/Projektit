﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using MySql.Data.MySqlClient;

namespace StudyPoint_5._0
{
    public partial class KIRJAUDU : UserControl
    {
        YHDISTA yhteys = new YHDISTA();
        
        public KIRJAUDU()
        {
            InitializeComponent();
        }

        private void KIRJAUDU_Load(object sender, EventArgs e)
        {
           
        }

        private void KirjauduBT01_Click(object sender, EventArgs e)
        {
            String usr = KayttajatnsTB.Text;
            String pass = SalasanaTB.Text;

            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable dt = new DataTable();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM `opiskelija` WHERE `kayttaja` = @usn and `salasana` = @pss", yhteys.otaYhteys());
            cmd.Parameters.Add("@usn",MySqlDbType.VarChar).Value = usr;
            cmd.Parameters.Add("@pss", MySqlDbType.VarChar).Value = pass;

            adapter.SelectCommand = cmd;

            adapter.Fill(dt);


            // Tarkastetaan löytyykö käyttäjää tietokannasta.
            if (dt.Rows.Count > 0)
            {
                this.Hide();
                etusivu form1 = new etusivu();
                KayttajaForm form2 = new KayttajaForm();
                //MessageBox.Show("Kyllä");
                form1.Hide();
                form2.Show();
                //form1.Close();
                
            }
            else
            {
                MessageBox.Show("Ei");

            }

            
        }
    }
}
