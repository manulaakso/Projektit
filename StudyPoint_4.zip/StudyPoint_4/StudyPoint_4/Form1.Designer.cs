﻿namespace StudyPoint_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.user_adminBT = new System.Windows.Forms.Button();
            this.ota_yhteyttaBT = new System.Windows.Forms.Button();
            this.organisaatiommeBT = new System.Windows.Forms.Button();
            this.palvelummeBT = new System.Windows.Forms.Button();
            this.meistaBT = new System.Windows.Forms.Button();
            this.etusivuBT = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.etusivu1 = new StudyPoint_4.Etusivu1PL();
            this.yhteyslomake1 = new StudyPoint_4.Yhteyslomake();
            this.organisaatiommePL = new StudyPoint_4.OrganisaatiommePL();
            this.meista1 = new StudyPoint_4.MeistaPL();
            this.palvelummePL = new StudyPoint_4.PalvelummePL();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.user_adminBT);
            this.panel1.Controls.Add(this.ota_yhteyttaBT);
            this.panel1.Controls.Add(this.organisaatiommeBT);
            this.panel1.Controls.Add(this.palvelummeBT);
            this.panel1.Controls.Add(this.meistaBT);
            this.panel1.Controls.Add(this.etusivuBT);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(882, 70);
            this.panel1.TabIndex = 0;
            // 
            // user_adminBT
            // 
            this.user_adminBT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.user_adminBT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_adminBT.Location = new System.Drawing.Point(733, 15);
            this.user_adminBT.Name = "user_adminBT";
            this.user_adminBT.Size = new System.Drawing.Size(137, 40);
            this.user_adminBT.TabIndex = 5;
            this.user_adminBT.Text = "User / Admin";
            this.user_adminBT.UseVisualStyleBackColor = false;
            // 
            // ota_yhteyttaBT
            // 
            this.ota_yhteyttaBT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ota_yhteyttaBT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ota_yhteyttaBT.Location = new System.Drawing.Point(577, 15);
            this.ota_yhteyttaBT.Name = "ota_yhteyttaBT";
            this.ota_yhteyttaBT.Size = new System.Drawing.Size(150, 40);
            this.ota_yhteyttaBT.TabIndex = 4;
            this.ota_yhteyttaBT.Text = "Ota yhteyttä";
            this.ota_yhteyttaBT.UseVisualStyleBackColor = false;
            this.ota_yhteyttaBT.Click += new System.EventHandler(this.ota_yhteyttaBT_Click);
            // 
            // organisaatiommeBT
            // 
            this.organisaatiommeBT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.organisaatiommeBT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.organisaatiommeBT.Location = new System.Drawing.Point(404, 15);
            this.organisaatiommeBT.Name = "organisaatiommeBT";
            this.organisaatiommeBT.Size = new System.Drawing.Size(167, 40);
            this.organisaatiommeBT.TabIndex = 3;
            this.organisaatiommeBT.Text = "Organisaatiomme";
            this.organisaatiommeBT.UseVisualStyleBackColor = false;
            this.organisaatiommeBT.Click += new System.EventHandler(this.organisaatiommeBT_Click);
            // 
            // palvelummeBT
            // 
            this.palvelummeBT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.palvelummeBT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.palvelummeBT.Location = new System.Drawing.Point(248, 15);
            this.palvelummeBT.Name = "palvelummeBT";
            this.palvelummeBT.Size = new System.Drawing.Size(150, 40);
            this.palvelummeBT.TabIndex = 2;
            this.palvelummeBT.Text = "Palvelumme";
            this.palvelummeBT.UseVisualStyleBackColor = false;
            this.palvelummeBT.Click += new System.EventHandler(this.palvelummeBT_Click);
            // 
            // meistaBT
            // 
            this.meistaBT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.meistaBT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.meistaBT.Location = new System.Drawing.Point(126, 15);
            this.meistaBT.Name = "meistaBT";
            this.meistaBT.Size = new System.Drawing.Size(116, 40);
            this.meistaBT.TabIndex = 1;
            this.meistaBT.Text = "Meistä";
            this.meistaBT.UseVisualStyleBackColor = false;
            this.meistaBT.Click += new System.EventHandler(this.meistaBT_Click);
            // 
            // etusivuBT
            // 
            this.etusivuBT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.etusivuBT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etusivuBT.Location = new System.Drawing.Point(12, 15);
            this.etusivuBT.Name = "etusivuBT";
            this.etusivuBT.Size = new System.Drawing.Size(108, 40);
            this.etusivuBT.TabIndex = 0;
            this.etusivuBT.Text = "Etusivu";
            this.etusivuBT.UseVisualStyleBackColor = false;
            this.etusivuBT.Click += new System.EventHandler(this.etusivuBT_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.etusivu1);
            this.panel2.Controls.Add(this.yhteyslomake1);
            this.panel2.Controls.Add(this.organisaatiommePL);
            this.panel2.Controls.Add(this.meista1);
            this.panel2.Controls.Add(this.palvelummePL);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 70);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(882, 383);
            this.panel2.TabIndex = 1;
            // 
            // etusivu1
            // 
            this.etusivu1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.etusivu1.Location = new System.Drawing.Point(0, 0);
            this.etusivu1.Name = "etusivu1";
            this.etusivu1.Size = new System.Drawing.Size(882, 383);
            this.etusivu1.TabIndex = 0;
            // 
            // yhteyslomake1
            // 
            this.yhteyslomake1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.yhteyslomake1.Location = new System.Drawing.Point(0, 0);
            this.yhteyslomake1.Name = "yhteyslomake1";
            this.yhteyslomake1.Size = new System.Drawing.Size(882, 383);
            this.yhteyslomake1.TabIndex = 3;
            // 
            // organisaatiommePL
            // 
            this.organisaatiommePL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.organisaatiommePL.Location = new System.Drawing.Point(0, 0);
            this.organisaatiommePL.Name = "organisaatiommePL";
            this.organisaatiommePL.Size = new System.Drawing.Size(882, 383);
            this.organisaatiommePL.TabIndex = 2;
            // 
            // meista1
            // 
            this.meista1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.meista1.Location = new System.Drawing.Point(0, 0);
            this.meista1.Name = "meista1";
            this.meista1.Size = new System.Drawing.Size(882, 383);
            this.meista1.TabIndex = 1;
            // 
            // palvelummePL
            // 
            this.palvelummePL.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.palvelummePL.Location = new System.Drawing.Point(0, 0);
            this.palvelummePL.Margin = new System.Windows.Forms.Padding(5);
            this.palvelummePL.Name = "palvelummePL";
            this.palvelummePL.Size = new System.Drawing.Size(882, 383);
            this.palvelummePL.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 453);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button user_adminBT;
        private System.Windows.Forms.Button ota_yhteyttaBT;
        private System.Windows.Forms.Button organisaatiommeBT;
        private System.Windows.Forms.Button palvelummeBT;
        private System.Windows.Forms.Button meistaBT;
        private System.Windows.Forms.Button etusivuBT;
        private System.Windows.Forms.Panel panel2;
        private Etusivu1PL etusivu1;
        private MeistaPL meista1;
        private PalvelummePL palvelummePL;
        private OrganisaatiommePL organisaatiommePL;
        private Yhteyslomake yhteyslomake1;
    }
}

