﻿namespace StudyPoint_4
{
    partial class Etusivu1PL
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.etusivu1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // etusivu1
            // 
            this.etusivu1.AutoSize = true;
            this.etusivu1.Font = new System.Drawing.Font("Franklin Gothic Medium", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etusivu1.Location = new System.Drawing.Point(180, 153);
            this.etusivu1.Name = "etusivu1";
            this.etusivu1.Size = new System.Drawing.Size(504, 47);
            this.etusivu1.TabIndex = 0;
            this.etusivu1.Text = "WELCOME TO STUDYPOINT";
            // 
            // Etusivu1PL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.etusivu1);
            this.Name = "Etusivu1PL";
            this.Size = new System.Drawing.Size(882, 383);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label etusivu1;
    }
}
