﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudyPoint_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void etusivuBT_Click(object sender, EventArgs e)
        {
            etusivu1.BringToFront();
        }

        private void meistaBT_Click(object sender, EventArgs e)
        {
            meista1.BringToFront();
        }

        private void palvelummeBT_Click(object sender, EventArgs e)
        {
            palvelummePL.BringToFront();
        }

        private void organisaatiommeBT_Click(object sender, EventArgs e)
        {
            organisaatiommePL.BringToFront();
        }

        private void ota_yhteyttaBT_Click(object sender, EventArgs e)
        {
            yhteyslomake1.BringToFront();
        }
    }
}
