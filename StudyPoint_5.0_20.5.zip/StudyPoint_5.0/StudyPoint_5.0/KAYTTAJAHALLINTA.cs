﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace StudyPoint_5._0
{
    public partial class KAYTTAJAHALLINTA : UserControl
    {
        OPISKELIJA oppilas = new OPISKELIJA(); 
        public KAYTTAJAHALLINTA()
        {
            InitializeComponent();
        }

        private void ExitBT_Click(object sender, EventArgs e)
        {
            DialogResult Exit;

            try
            {
                Exit = MessageBox.Show("Haluatko varmasti poistua?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (Exit == DialogResult.Yes)
                {
                    Application.Exit();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        private void ResetBT_Click(object sender, EventArgs e)
        {
            
        }

        private void LisaaBT_Click(object sender, EventArgs e)
        {

           

        }

        private void paivitaBT_Click(object sender, EventArgs e)
        {
           
        }

        private void PoistaBT_Click(object sender, EventArgs e)
        {

        }

        private void KAYTTAJAHALLINTA_Load(object sender, EventArgs e)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT `oid`, `etunimi`,`sukunimi`,`puhelin`,`sahkoposti`,`lahiosoite`,`postitoimipaikka`, `postinro`, `kayttaja` FROM `opiskelija`");
            TiedotDG.ReadOnly = true;
            TiedotDG.DataSource = oppilas.getStudent(cmd);
        }
    }
}
